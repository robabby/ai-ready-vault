# Working Agreement Backup

This is a backup of key working agreement details. Update this when you make significant changes to your collaboration style with Claude.

## Communication Preferences

- **Tone**:
- **Detail level**:
- **Question style**:

## Domain Context

Key background information Claude should know:

-
-

## Preferred Patterns

Things that work well:

-

## Anti-patterns

Things to avoid:

-

## Last Updated

2026-01-08
