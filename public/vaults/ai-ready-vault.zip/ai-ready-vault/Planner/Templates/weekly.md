---
date: {{date:YYYY-MM-DD}}
type: weekly
week: {{date:W}}
---

# Week {{date:W}} - {{date:YYYY}}

## Goals This Week

1.
2.
3.

## Daily Notes

- [[{{monday:YYYY-MM-DD}}|Monday]]
- [[{{tuesday:YYYY-MM-DD}}|Tuesday]]
- [[{{wednesday:YYYY-MM-DD}}|Wednesday]]
- [[{{thursday:YYYY-MM-DD}}|Thursday]]
- [[{{friday:YYYY-MM-DD}}|Friday]]

## Projects

```dataview
TABLE status, progress
FROM "Projects/Active"
WHERE file.name != ".gitkeep"
```

## Weekly Review

### Accomplishments


### Challenges


### Next Week Focus

