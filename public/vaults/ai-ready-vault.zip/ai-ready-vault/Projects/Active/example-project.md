---
created: 2024-01-15
type: project
status: active
due: 2024-02-15
tags: [example]
---

# Example Project

## Overview

This is an example project to demonstrate the project template structure.

## Objectives

- [ ] Set up project structure
- [ ] Define key milestones
- [x] Create initial documentation

## Tasks

- [x] Create project note
- [ ] Break down into subtasks
- [ ] Set up tracking

## Resources

- [[CLAUDE]] - AI context
- [[Areas/AI/Memory/Procedural/session-workflow|Session Workflow]]

## Notes

This project serves as a template example. Delete or archive when ready.

## Progress Log

### 2024-01-15
- Initial creation
- Linked to relevant resources
