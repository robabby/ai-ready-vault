---
date: {{date:YYYY-MM-DD}}
type: daily
---

# {{date:dddd, MMMM D, YYYY}}

## Morning

- [ ]

## Priorities

1.
2.
3.

## Notes


## Evening Reflection

What went well today?

What could be improved?
