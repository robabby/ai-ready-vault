---
date: {{date:YYYY-MM-DD}}
type: monthly
month: {{date:MMMM}}
year: {{date:YYYY}}
---

# {{date:MMMM YYYY}}

## Monthly Goals

1.
2.
3.

## Weeks

- [[{{date:YYYY}}-W{{date:W}}|Week 1]]

## Projects

```dataview
TABLE status, due, progress
FROM "Projects/Active"
WHERE file.name != ".gitkeep"
```

## Monthly Review

### Key Accomplishments


### Challenges Faced


### Lessons Learned


### Next Month Focus

