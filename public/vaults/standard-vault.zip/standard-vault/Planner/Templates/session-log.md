---
date: {{date:YYYY-MM-DD}}
type: session
summary:
participants: [Claude, User]
tags: []
---

# Session Log - {{date:YYYY-MM-DD HH:mm}}

## Context

What were we working on?

## Summary

Key points from this session.

## Decisions Made

-

## Action Items

- [ ]

## Memories to Create

- [ ] Create memory:

## Related

- [[CLAUDE]]
- [[Areas/AI/Memory/Memory|Memory Dashboard]]
