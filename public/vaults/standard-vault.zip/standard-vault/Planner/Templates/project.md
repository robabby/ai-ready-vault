---
created: {{date:YYYY-MM-DD}}
type: project
status: active
due:
tags: []
---

# Project Name

## Overview

Brief description of the project and its goals.

## Objectives

- [ ] Objective 1
- [ ] Objective 2
- [ ] Objective 3

## Tasks

- [ ] Task 1
- [ ] Task 2
- [ ] Task 3

## Resources

-

## Notes

## Progress Log

### {{date:YYYY-MM-DD}}
- Initial creation
